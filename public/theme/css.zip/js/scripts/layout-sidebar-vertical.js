"use strict";

$(document).ready(function () {
  "use strict";

  $(function () {
    $('#menu').metisMenu();
  });
});